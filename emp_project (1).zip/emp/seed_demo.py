"""Optional: python seed_demo.py  -> sample course, exam, rubrics, examiner, student."""
from datetime import date, timedelta
from werkzeug.security import generate_password_hash
from app import app, db
from models import Course, Exam, Rubric, User

with app.app_context():
    if not Course.query.first():
        ex = User(email="examiner@emp.com", name="Dr. Examiner", role="examiner", department="ECE",
                  status="active", password_hash=generate_password_hash("examiner123"))
        st = User(email="student@emp.com", name="Sample Student", role="student", department="ECE",
                  password_hash=generate_password_hash("student123"))
        c = Course(code="EC101", name="Digital Electronics", description="Demo course")
        db.session.add_all([ex, st, c]); db.session.flush()
        e = Exam(course_id=c.id, name="Lab Viva", exam_type="Viva", duration=15, max_marks=50,
                 status="Slot Creation", examiner_id=ex.id, slot_start=date.today(),
                 slot_end=date.today() + timedelta(7), book_start=date.today(), book_end=date.today() + timedelta(14))
        db.session.add(e); db.session.flush()
        db.session.add_all([Rubric(exam_id=e.id, criterion="Concepts", max_marks=25, weightage=50),
                            Rubric(exam_id=e.id, criterion="Communication", max_marks=25, weightage=50)])
        db.session.commit()
    print("Demo data ready: examiner@emp.com/examiner123, student@emp.com/student123")
