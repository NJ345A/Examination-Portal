import os
from datetime import date, datetime
from functools import wraps

from flask import (Flask, abort, flash, jsonify, redirect, render_template,
                   request, session, url_for)
from markupsafe import Markup, escape
from werkzeug.security import check_password_hash, generate_password_hash

from models import (EXAM_STATUSES, EXAM_TYPES, Booking, Course, Exam, Rubric,
                    Score, Slot, User, db)

BASE = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config.update(SECRET_KEY="emp-dev-secret-change-me",
                  SQLALCHEMY_DATABASE_URI="sqlite:///" + os.path.join(BASE, "emp.db"))
db.init_app(app)

ADMIN_EMAIL, ADMIN_PASSWORD = "admin@emp.com", "admin123"


# ---------------------------------------------------------------- helpers
def init_db():
    """Create tables programmatically and seed the pre-existing admin."""
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(role="admin").first():
            db.session.add(User(email=ADMIN_EMAIL, name="Administrator", role="admin",
                                password_hash=generate_password_hash(ADMIN_PASSWORD)))
            db.session.commit()


def current_user():
    uid = session.get("uid")
    return db.session.get(User, uid) if uid else None


def role_required(*roles):
    def deco(f):
        @wraps(f)
        def wrapper(*a, **k):
            u = current_user()
            if not u or u.status == "deactivated":
                session.clear()
                flash("Please log in.", "warning")
                return redirect(url_for("login"))
            if u.role not in roles:
                abort(403)
            if u.role == "examiner" and u.status != "active":
                return render_template("pending.html")      # awaiting admin approval
            return f(*a, **k)
        return wrapper
    return deco


def pdate(s):
    return date.fromisoformat(s) if s else None


def ptime(s):
    return datetime.strptime(s[:5], "%H:%M").time()


def overlap(a, b):
    return a.start_time < b.end_time and b.start_time < a.end_time


def examiner_clash(examiner_id, day, start, end, ignore_id=None):
    for s in Slot.query.filter_by(examiner_id=examiner_id, date=day):
        if s.id != ignore_id and s.status != "Cancelled" and start < s.end_time and s.start_time < end:
            return True
    return False


@app.context_processor
def inject():
    return dict(me=current_user(), today=date.today())


@app.template_filter("badge")
def badge(s):
    c = {"Available": "success", "Booked": "primary", "Full": "warning", "Cancelled": "secondary",
         "Completed": "success", "Draft": "secondary", "Slot Creation": "info",
         "Booking Open": "primary", "Closed": "dark", "active": "success", "pending": "warning",
         "deactivated": "danger", "Active": "success", "Inactive": "secondary"}
    return Markup(f'<span class="badge text-bg-{c.get(s, "secondary")}">{escape(s)}</span>')


@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", msg="You are not allowed to access this page."), 403


# ---------------------------------------------------------------- auth
@app.route("/")
def index():
    u = current_user()
    if not u:
        return redirect(url_for("login"))
    return redirect(url_for({"admin": "admin_dashboard", "examiner": "examiner_dashboard",
                             "student": "student_dashboard"}[u.role]))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(email=request.form.get("email", "").strip().lower()).first()
        if not u or not check_password_hash(u.password_hash, request.form.get("password", "")):
            flash("Invalid email or password.", "danger")
        elif u.status == "deactivated":
            flash("Your account is deactivated. Contact the admin.", "danger")
        else:
            session.clear()
            session["uid"] = u.id
            return redirect(url_for("index"))
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        email, name, role = f.get("email", "").strip().lower(), f.get("name", "").strip(), f.get("role")
        if role not in ("examiner", "student"):
            flash("Choose Examiner or Student.", "danger")
        elif not email or not name or len(f.get("password", "")) < 6:
            flash("Name, email and a password of at least 6 characters are required.", "danger")
        elif User.query.filter_by(email=email).first():
            flash("Email already registered.", "danger")
        else:
            db.session.add(User(email=email, name=name, role=role, phone=f.get("phone"),
                                department=f.get("department"),
                                status="pending" if role == "examiner" else "active",
                                password_hash=generate_password_hash(f["password"])))
            db.session.commit()
            flash("Registered! " + ("Await admin approval before accessing the dashboard."
                                    if role == "examiner" else "You can log in now."), "success")
            return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------- admin
@app.route("/admin")
@role_required("admin")
def admin_dashboard():
    stats = {"Courses": Course.query.count(), "Examinations": Exam.query.count(),
             "Examiners": User.query.filter_by(role="examiner").count(),
             "Students": User.query.filter_by(role="student").count(),
             "Slots": Slot.query.count(), "Bookings": Booking.query.count()}
    pending = User.query.filter_by(role="examiner", status="pending").count()
    return render_template("admin/dashboard.html", stats=stats, pending=pending)


@app.route("/admin/courses")
@role_required("admin")
def admin_courses():
    edit = db.session.get(Course, request.args.get("edit", type=int) or 0)
    return render_template("admin/courses.html", courses=Course.query.all(), c=edit)


@app.post("/admin/courses/save")
@role_required("admin")
def admin_course_save():
    f = request.form
    c = db.session.get(Course, int(f["id"])) if f.get("id") else Course()
    code = f.get("code", "").strip().upper()
    dup = Course.query.filter(Course.code == code, Course.id != (c.id or 0)).first()
    if not code or not f.get("name", "").strip() or dup:
        flash("Course code and name are required; code must be unique.", "danger")
        return redirect(url_for("admin_courses"))
    c.code, c.name = code, f["name"].strip()
    c.description, c.status = f.get("description"), f.get("status", "Active")
    c.credits = int(f.get("credits") or 0)
    db.session.add(c)
    db.session.commit()
    flash("Course saved.", "success")
    return redirect(url_for("admin_courses"))


@app.post("/admin/courses/<int:id>/delete")
@role_required("admin")
def admin_course_delete(id):
    c = db.get_or_404(Course, id)
    if c.exams:
        flash("Course has examinations; mark it Inactive instead of deleting.", "warning")
    else:
        db.session.delete(c)
        db.session.commit()
        flash("Course removed.", "success")
    return redirect(url_for("admin_courses"))


@app.route("/admin/exams")
@role_required("admin")
def admin_exams():
    edit = db.session.get(Exam, request.args.get("edit", type=int) or 0)
    return render_template("admin/exams.html", exams=Exam.query.order_by(Exam.id.desc()).all(), e=edit,
                           courses=Course.query.filter_by(status="Active").all(), types=EXAM_TYPES,
                           statuses=EXAM_STATUSES,
                           examiners=User.query.filter_by(role="examiner", status="active").all())


@app.post("/admin/exams/save")
@role_required("admin")
def admin_exam_save():
    f = request.form
    e = db.session.get(Exam, int(f["id"])) if f.get("id") else Exam()
    try:
        e.course_id, e.name = int(f["course_id"]), f["name"].strip()
        e.exam_type, e.duration, e.max_marks = f["exam_type"], int(f["duration"]), int(f["max_marks"])
        e.slot_start, e.slot_end = pdate(f.get("slot_start")), pdate(f.get("slot_end"))
        e.book_start, e.book_end = pdate(f.get("book_start")), pdate(f.get("book_end"))
        e.examiner_id = int(f["examiner_id"]) if f.get("examiner_id") else None
        e.status = f.get("status", "Draft")
        e.venue, e.instructions = f.get("venue"), f.get("instructions")
    except (KeyError, ValueError):
        flash("Invalid input.", "danger")
        return redirect(url_for("admin_exams"))
    if e.exam_type not in EXAM_TYPES or e.status not in EXAM_STATUSES or not e.name \
            or e.duration < 1 or e.max_marks < 1:
        flash("Invalid examination details.", "danger")
        return redirect(url_for("admin_exams"))
    if (e.slot_start and e.slot_end and e.slot_start > e.slot_end) or \
            (e.book_start and e.book_end and e.book_start > e.book_end):
        flash("Start date must not be after end date.", "danger")
        return redirect(url_for("admin_exams"))
    db.session.add(e)
    db.session.commit()
    flash("Examination saved.", "success")
    return redirect(url_for("admin_exam_detail", id=e.id))


@app.post("/admin/exams/<int:id>/delete")
@role_required("admin")
def admin_exam_delete(id):
    e = db.get_or_404(Exam, id)
    if any(s.bookings for s in e.slots):
        flash("Examination has bookings; set status to Closed/Completed instead.", "warning")
    else:
        db.session.delete(e)
        db.session.commit()
        flash("Examination removed.", "success")
    return redirect(url_for("admin_exams"))


@app.route("/admin/exams/<int:id>")
@role_required("admin")
def admin_exam_detail(id):
    e = db.get_or_404(Exam, id)
    return render_template("admin/exam_detail.html", e=e,
                           r=db.session.get(Rubric, request.args.get("redit", type=int) or 0),
                           rubric_total=sum(x.max_marks for x in e.rubrics))


@app.post("/admin/exams/<int:id>/status")
@role_required("admin")
def admin_exam_status(id):
    e = db.get_or_404(Exam, id)
    new = {"open_slots": "Slot Creation", "close_slots": "Draft", "open_booking": "Booking Open",
           "close_booking": "Closed", "complete": "Completed"}.get(request.form.get("action"))
    if new:
        e.status = new
        db.session.commit()
        flash(f"Status changed to {new}.", "success")
    return redirect(url_for("admin_exam_detail", id=id))


@app.post("/admin/exams/<int:id>/rubrics")
@role_required("admin")
def admin_rubric_save(id):
    e = db.get_or_404(Exam, id)
    f = request.form
    r = db.session.get(Rubric, int(f["rid"])) if f.get("rid") else Rubric(exam_id=e.id)
    try:
        r.criterion, r.max_marks = f["criterion"].strip(), int(f["max_marks"])
        r.weightage, r.description = float(f.get("weightage") or 0), f.get("description")
    except (KeyError, ValueError):
        flash("Invalid rubric input.", "danger")
        return redirect(url_for("admin_exam_detail", id=id))
    if not r.criterion or r.max_marks < 1 or r.weightage < 0:
        flash("Invalid rubric input.", "danger")
    else:
        db.session.add(r)
        db.session.commit()
        flash("Rubric saved.", "success")
    return redirect(url_for("admin_exam_detail", id=id))


@app.post("/admin/rubrics/<int:id>/delete")
@role_required("admin")
def admin_rubric_delete(id):
    r = db.get_or_404(Rubric, id)
    eid = r.exam_id
    if Score.query.filter_by(rubric_id=id).first():
        flash("Rubric already used in evaluations; cannot delete.", "warning")
    else:
        db.session.delete(r)
        db.session.commit()
    return redirect(url_for("admin_exam_detail", id=eid))


@app.route("/admin/examiners")
@role_required("admin")
def admin_examiners():
    return render_template("admin/examiners.html", examiners=User.query.filter_by(role="examiner").all())


@app.post("/admin/examiners/add")
@role_required("admin")
def admin_examiner_add():
    f = request.form
    email = f.get("email", "").strip().lower()
    if not email or not f.get("name") or len(f.get("password", "")) < 6 or User.query.filter_by(email=email).first():
        flash("Name, unique email and 6+ char password required.", "danger")
    else:
        db.session.add(User(email=email, name=f["name"].strip(), role="examiner", phone=f.get("phone"),
                            department=f.get("department"), status="active",
                            password_hash=generate_password_hash(f["password"])))
        db.session.commit()
        flash("Examiner added.", "success")
    return redirect(url_for("admin_examiners"))


@app.post("/admin/examiners/<int:id>/<action>")
@role_required("admin")
def admin_examiner_action(id, action):
    u = db.get_or_404(User, id)
    if u.role != "examiner" or action not in ("approve", "deactivate", "activate"):
        abort(404)
    u.status = "deactivated" if action == "deactivate" else "active"
    db.session.commit()
    flash(f"Examiner {u.name}: {u.status}.", "success")
    return redirect(url_for("admin_examiners"))


@app.route("/admin/students")
@role_required("admin")
def admin_students():
    return render_template("admin/students.html", students=User.query.filter_by(role="student").all())


@app.route("/admin/slots")
@role_required("admin")
def admin_slots():
    return render_template("admin/slots.html", slots=Slot.query.order_by(Slot.date, Slot.start_time).all(),
                           examiners=User.query.filter_by(role="examiner", status="active").all())


@app.post("/admin/slots/<int:id>/examiner")
@role_required("admin")
def admin_slot_examiner(id):
    s = db.get_or_404(Slot, id)
    new = db.session.get(User, request.form.get("examiner_id", type=int) or 0)
    if not new or new.role != "examiner" or new.status != "active":
        flash("Choose an active examiner.", "danger")
    elif examiner_clash(new.id, s.date, s.start_time, s.end_time, s.id):
        flash("That examiner already has an overlapping slot.", "danger")
    else:
        s.examiner_id = new.id
        db.session.commit()
        flash("Examiner changed.", "success")
    return redirect(url_for("admin_slots"))


@app.route("/admin/bookings")
@role_required("admin")
def admin_bookings():
    slots = {}
    for s in Slot.query.filter_by(status="Available"):
        slots.setdefault(s.exam_id, []).append(s)
    return render_template("admin/bookings.html", bookings=Booking.query.order_by(Booking.id.desc()).all(),
                           slots_by_exam=slots)


@app.post("/admin/bookings/<int:id>/reschedule")
@role_required("admin")
def admin_reschedule(id):
    b = db.get_or_404(Booking, id)
    new = db.session.get(Slot, request.form.get("slot_id", type=int) or 0)
    if b.status != "Booked":
        flash("Only active bookings can be rescheduled.", "warning")
    elif not new or new.exam_id != b.slot.exam_id or new.status != "Available" or new.available_seats < 1:
        flash("Pick an available slot of the same examination.", "danger")
    else:
        old = b.slot
        b.slot_id = new.id
        db.session.flush()
        db.session.refresh(old)
        db.session.refresh(new)
        old.refresh()
        new.refresh()
        db.session.commit()
        flash("Booking rescheduled.", "success")
    return redirect(url_for("admin_bookings"))


@app.route("/admin/search")
@role_required("admin")
def admin_search():
    q = request.args.get("q", "").strip()
    like, idq = f"%{q}%", (int(q) if q.isdigit() else -1)
    o = db.or_
    students = User.query.filter(User.role == "student", o(User.name.ilike(like), User.email.ilike(like), User.id == idq)).all()
    examiners = User.query.filter(User.role == "examiner", o(User.name.ilike(like), User.email.ilike(like), User.id == idq)).all()
    exams = Exam.query.join(Course).filter(o(Exam.name.ilike(like), Course.code.ilike(like), Exam.id == idq)).all()
    bookings = (Booking.query.join(User, Booking.student_id == User.id).join(Slot, Booking.slot_id == Slot.id)
                .join(Exam, Slot.exam_id == Exam.id)
                .filter(o(User.name.ilike(like), Exam.name.ilike(like), Booking.id == idq)).all())
    return render_template("admin/search.html", q=q, students=students, examiners=examiners,
                           exams=exams, bookings=bookings)


# ---------------------------------------------------------------- admin JSON API
@app.route("/api/<res>")
@role_required("admin")
def api(res):
    if res == "exams":
        data = [dict(id=e.id, course=e.course.code, name=e.name, type=e.exam_type, status=e.status,
                     max_marks=e.max_marks) for e in Exam.query]
    elif res in ("students", "examiners"):
        data = [dict(id=u.id, name=u.name, email=u.email, status=u.status)
                for u in User.query.filter_by(role=res[:-1])]
    elif res == "bookings":
        data = [dict(id=b.id, student=b.student.name, exam=b.slot.exam.name, date=str(b.slot.date),
                     status=b.status, marks=b.total_marks) for b in Booking.query]
    else:
        abort(404)
    return jsonify(data)


# ---------------------------------------------------------------- examiner
@app.route("/examiner")
@role_required("examiner")
def examiner_dashboard():
    me = current_user()
    exams = Exam.query.filter_by(examiner_id=me.id).all()
    slots = Slot.query.filter_by(examiner_id=me.id).all()
    bookings = [b for s in slots for b in s.bookings if b.status in ("Booked", "Completed")]
    pending = [b for b in bookings if not b.evaluated]
    return render_template("examiner/dashboard.html", exams=exams, slots=slots,
                           booked=len(bookings), pending=pending)


@app.route("/examiner/slots")
@role_required("examiner")
def examiner_slots():
    me = current_user()
    edit = db.session.get(Slot, request.args.get("edit", type=int) or 0)
    if edit and edit.examiner_id != me.id:
        abort(403)
    exams = [e for e in Exam.query.filter_by(examiner_id=me.id) if e.slot_creation_open()]
    return render_template("examiner/slots.html", slots=Slot.query.filter_by(examiner_id=me.id)
                           .order_by(Slot.date, Slot.start_time).all(), exams=exams, s=edit)


@app.post("/examiner/slots/save")
@role_required("examiner")
def examiner_slot_save():
    me, f = current_user(), request.form
    try:
        if f.get("id"):
            s = db.get_or_404(Slot, int(f["id"]))
            if s.examiner_id != me.id:
                abort(403)
            if not s.editable:
                flash("Slot can no longer be changed (booking has started or students booked).", "danger")
                return redirect(url_for("examiner_slots"))
        else:
            exam = db.get_or_404(Exam, int(f["exam_id"]))
            if exam.examiner_id != me.id:
                abort(403)
            if not exam.slot_creation_open():
                flash("Slot creation is not open for this examination.", "danger")
                return redirect(url_for("examiner_slots"))
            s = Slot(exam_id=exam.id, examiner_id=me.id)
        day, st, en, cap = pdate(f["date"]), ptime(f["start_time"]), ptime(f["end_time"]), int(f["capacity"])
    except (KeyError, ValueError):
        flash("Invalid input.", "danger")
        return redirect(url_for("examiner_slots"))
    if st >= en or cap < 1 or day < date.today():
        flash("Check date (not in the past), times (start < end) and capacity (>= 1).", "danger")
    elif examiner_clash(me.id, day, st, en, s.id):
        flash("You already have an overlapping slot.", "danger")
    else:
        s.date, s.start_time, s.end_time, s.capacity, s.location = day, st, en, cap, f.get("location")
        db.session.add(s)
        db.session.commit()
        flash("Slot saved.", "success")
    return redirect(url_for("examiner_slots"))


@app.post("/examiner/slots/<int:id>/delete")
@role_required("examiner")
def examiner_slot_delete(id):
    s = db.get_or_404(Slot, id)
    if s.examiner_id != current_user().id:
        abort(403)
    if not s.editable:
        flash("Slot can no longer be removed.", "danger")
    else:
        db.session.delete(s)
        db.session.commit()
        flash("Slot removed.", "success")
    return redirect(url_for("examiner_slots"))


@app.route("/examiner/slots/<int:id>/students")
@role_required("examiner")
def examiner_slot_students(id):
    s = db.get_or_404(Slot, id)
    if s.examiner_id != current_user().id:
        abort(403)
    return render_template("examiner/students.html", s=s)


@app.route("/examiner/evaluate/<int:id>", methods=["GET", "POST"])
@role_required("examiner")
def examiner_evaluate(id):
    b = db.get_or_404(Booking, id)
    if b.slot.examiner_id != current_user().id:       # only own slots' students
        abort(403)
    exam = b.slot.exam
    if b.status == "Cancelled":
        flash("Cancelled bookings cannot be evaluated.", "warning")
        return redirect(url_for("examiner_slot_students", id=b.slot_id))
    if exam.status == "Completed":
        flash("Results are published; evaluation is locked.", "warning")
        return redirect(url_for("examiner_slot_students", id=b.slot_id))
    old = {s.rubric_id: s.marks for s in b.scores}
    if request.method == "POST":
        new = {}
        try:
            for r in exam.rubrics:
                m = float(request.form.get(f"m_{r.id}", ""))
                if not 0 <= m <= r.max_marks:
                    raise ValueError
                new[r.id] = m
        except ValueError:
            flash("Enter marks between 0 and each criterion's maximum.", "danger")
            return render_template("examiner/evaluate.html", b=b, exam=exam, old=old)
        for s in list(b.scores):
            db.session.delete(s)
        db.session.flush()
        for rid, m in new.items():
            db.session.add(Score(booking_id=b.id, rubric_id=rid, marks=m))
        db.session.flush()
        db.session.refresh(b)
        b.remarks, b.evaluated, b.status = request.form.get("remarks"), True, "Completed"
        b.total_marks = b.compute_total()
        if all(x.evaluated for x in b.slot.bookings if x.status in ("Booked", "Completed")):
            b.slot.status = "Completed"
        db.session.commit()
        flash("Marks and remarks submitted.", "success")
        return redirect(url_for("examiner_slot_students", id=b.slot_id))
    if not exam.rubrics:
        flash("No rubrics defined for this examination yet. Ask the admin to add them.", "warning")
    return render_template("examiner/evaluate.html", b=b, exam=exam, old=old)


# ---------------------------------------------------------------- student
@app.route("/student")
@role_required("student")
def student_dashboard():
    me = current_user()
    mine = Booking.query.filter_by(student_id=me.id).all()
    active = [b for b in mine if b.status == "Booked"]
    open_exams = [e for e in Exam.query.filter_by(status="Booking Open") if e.course.status == "Active"]
    open_slots = [s for e in open_exams for s in e.slots if s.status == "Available"]
    upcoming = [b for b in active if b.slot.date >= date.today()]
    results = [b for b in mine if b.evaluated and b.slot.exam.status == "Completed"]
    return render_template("student/dashboard.html", open_exams=open_exams, open_slots=open_slots[:10],
                           upcoming=upcoming, active=active, results=results)


@app.route("/student/exams")
@role_required("student")
def student_exams():
    q, typ, cid = request.args.get("q", "").strip(), request.args.get("type", ""), request.args.get("course", type=int)
    qs = Exam.query.join(Course).filter(Exam.status != "Draft", Course.status == "Active")
    if q:
        qs = qs.filter(db.or_(Exam.name.ilike(f"%{q}%"), Course.code.ilike(f"%{q}%"), Course.name.ilike(f"%{q}%")))
    if typ:
        qs = qs.filter(Exam.exam_type == typ)
    if cid:
        qs = qs.filter(Exam.course_id == cid)
    return render_template("student/exams.html", exams=qs.all(), q=q, typ=typ, cid=cid, types=EXAM_TYPES,
                           courses=Course.query.filter_by(status="Active").all())


@app.route("/student/exams/<int:id>")
@role_required("student")
def student_exam_slots(id):
    e = db.get_or_404(Exam, id)
    mine = Booking.query.join(Slot).filter(Booking.student_id == current_user().id, Slot.exam_id == id,
                                           Booking.status.in_(["Booked", "Completed"])).first()
    return render_template("student/exam_slots.html", e=e, mine=mine,
                           slots=sorted(e.slots, key=lambda s: (s.date, s.start_time)))


@app.post("/student/slots/<int:id>/book")
@role_required("student")
def student_book(id):
    me, s = current_user(), db.get_or_404(Slot, id)
    e = s.exam
    back = redirect(url_for("student_exam_slots", id=e.id))
    if not e.booking_open():
        flash("Booking is not open for this examination.", "danger")
        return back
    if s.status != "Available" or s.available_seats < 1:
        flash("Slot is full or unavailable.", "danger")
        return back
    active = Booking.query.filter(Booking.student_id == me.id, Booking.status.in_(["Booked", "Completed"])).all()
    if any(b.slot.exam_id == e.id for b in active):
        flash("You already have a booking for this examination.", "danger")
        return back
    if any(b.slot.date == s.date and overlap(b.slot, s) for b in active):
        flash("This slot clashes with another of your bookings.", "danger")
        return back
    db.session.add(Booking(student_id=me.id, slot_id=s.id))
    db.session.flush()
    db.session.refresh(s)
    s.refresh()                                   # auto-close when capacity reached
    db.session.commit()
    flash("Slot booked.", "success")
    return redirect(url_for("student_bookings"))


@app.post("/student/bookings/<int:id>/cancel")
@role_required("student")
def student_cancel(id):
    b = db.get_or_404(Booking, id)
    if b.student_id != current_user().id:
        abort(403)
    if b.status != "Booked":
        flash("Only active bookings can be cancelled.", "warning")
    elif not b.slot.exam.before_booking_deadline():
        flash("Booking deadline has passed; cancellation not allowed.", "danger")
    else:
        b.status = "Cancelled"
        db.session.flush()
        db.session.refresh(b.slot)
        b.slot.refresh()
        db.session.commit()
        flash("Booking cancelled.", "success")
    return redirect(url_for("student_bookings"))


@app.route("/student/bookings")
@role_required("student")
def student_bookings():
    bs = Booking.query.filter_by(student_id=current_user().id).order_by(Booking.id.desc()).all()
    return render_template("student/bookings.html", bookings=bs)


@app.route("/student/results")
@role_required("student")
def student_results():
    bs = [b for b in Booking.query.filter_by(student_id=current_user().id)
          if b.evaluated and b.slot.exam.status == "Completed"]
    return render_template("student/results.html", bookings=bs)


@app.route("/student/profile", methods=["GET", "POST"])
@role_required("student")
def student_profile():
    me = current_user()
    if request.method == "POST":
        f = request.form
        if not f.get("name", "").strip():
            flash("Name is required.", "danger")
        else:
            me.name, me.phone, me.department = f["name"].strip(), f.get("phone"), f.get("department")
            if f.get("password"):
                if len(f["password"]) < 6:
                    flash("Password must be 6+ characters.", "danger")
                    return render_template("student/profile.html")
                me.password_hash = generate_password_hash(f["password"])
            db.session.commit()
            flash("Profile updated.", "success")
    return render_template("student/profile.html")


init_db()
if __name__ == "__main__":
    app.run(debug=True)
