from datetime import date, datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

EXAM_TYPES = ["Viva", "Practical", "Project Demo", "Assessment"]
EXAM_STATUSES = ["Draft", "Slot Creation", "Booking Open", "Closed", "Completed"]


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(10), nullable=False)          # admin / examiner / student
    phone = db.Column(db.String(20))
    department = db.Column(db.String(100))
    status = db.Column(db.String(12), default="active")      # active / pending / deactivated
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    credits = db.Column(db.Integer, default=0)
    status = db.Column(db.String(10), default="Active")      # Active / Inactive
    exams = db.relationship("Exam", back_populates="course")


class Exam(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey("course.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    exam_type = db.Column(db.String(20), nullable=False)
    duration = db.Column(db.Integer, nullable=False)          # minutes
    max_marks = db.Column(db.Integer, nullable=False)
    slot_start = db.Column(db.Date)
    slot_end = db.Column(db.Date)
    book_start = db.Column(db.Date)
    book_end = db.Column(db.Date)
    status = db.Column(db.String(20), default="Draft")
    venue = db.Column(db.String(120))
    instructions = db.Column(db.Text)
    examiner_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    course = db.relationship("Course", back_populates="exams")
    examiner = db.relationship("User")
    rubrics = db.relationship("Rubric", cascade="all, delete-orphan")
    slots = db.relationship("Slot", back_populates="exam", cascade="all, delete-orphan")

    @staticmethod
    def _in_window(start, end):
        t = date.today()
        return (start is None or start <= t) and (end is None or t <= end)

    def slot_creation_open(self):
        return self.status == "Slot Creation" and self._in_window(self.slot_start, self.slot_end)

    def booking_open(self):
        return self.status == "Booking Open" and self._in_window(self.book_start, self.book_end)

    def before_booking_deadline(self):
        return self.book_end is None or date.today() <= self.book_end


class Rubric(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exam.id"), nullable=False)
    criterion = db.Column(db.String(120), nullable=False)
    max_marks = db.Column(db.Integer, nullable=False)
    weightage = db.Column(db.Float, default=0)
    description = db.Column(db.Text)


class Slot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exam.id"), nullable=False)
    examiner_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    location = db.Column(db.String(120))
    status = db.Column(db.String(12), default="Available")   # Available / Full / Cancelled / Completed
    exam = db.relationship("Exam", back_populates="slots")
    examiner = db.relationship("User")
    bookings = db.relationship("Booking", back_populates="slot", cascade="all, delete-orphan")

    @property
    def booked_count(self):
        return sum(1 for b in self.bookings if b.status in ("Booked", "Completed"))

    @property
    def available_seats(self):
        return max(self.capacity - self.booked_count, 0)

    def refresh(self):
        if self.status in ("Available", "Full"):
            self.status = "Full" if self.available_seats == 0 else "Available"

    @property
    def editable(self):   # update/remove only before booking starts
        return self.exam.status in ("Draft", "Slot Creation") and self.booked_count == 0


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    slot_id = db.Column(db.Integer, db.ForeignKey("slot.id"), nullable=False)
    booked_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(12), default="Booked")      # Booked / Cancelled / Completed
    evaluated = db.Column(db.Boolean, default=False)
    total_marks = db.Column(db.Float)
    remarks = db.Column(db.Text)
    student = db.relationship("User")
    slot = db.relationship("Slot", back_populates="bookings")
    scores = db.relationship("Score", cascade="all, delete-orphan")

    def compute_total(self):
        exam = self.slot.exam
        sc = {s.rubric_id: s.marks for s in self.scores}
        wsum = sum(r.weightage or 0 for r in exam.rubrics)
        if wsum > 0:
            part = sum((sc.get(r.id, 0) / r.max_marks) * (r.weightage or 0)
                       for r in exam.rubrics if r.max_marks)
            return round(part / wsum * exam.max_marks, 2)
        return round(sum(sc.values()), 2)


class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey("booking.id"), nullable=False)
    rubric_id = db.Column(db.Integer, db.ForeignKey("rubric.id"), nullable=False)
    marks = db.Column(db.Float, nullable=False)
    rubric = db.relationship("Rubric")
