# Examination Management Portal (EMP)

Flask + Jinja2 + Bootstrap (CDN, no JS written) + SQLite (tables created in code).

## Run
    pip install -r requirements.txt
    python app.py            # http://127.0.0.1:5000
    python seed_demo.py      # optional demo course/exam/examiner/student

The database `emp.db` and the pre-existing admin are created automatically on first start.

## Logins
- Admin: admin@emp.com / admin123
- Demo (after seed): examiner@emp.com / examiner123, student@emp.com / student123

## Typical flow
1. Admin: add course -> add examination (assign examiner, set dates) -> add rubrics -> Manage page: "Open slot creation".
2. Examiner (approved by admin): Slots -> create slots.
3. Admin: "Open booking". Student: Exams -> Slots -> Book / Cancel (until booking end date).
4. Examiner: Slots -> Students -> Evaluate (marks per rubric + remarks).
5. Admin: "Mark completed" publishes results to students.

Admin JSON APIs: /api/exams, /api/students, /api/examiners, /api/bookings (admin login required).
